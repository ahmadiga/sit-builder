from django.apps import AppConfig


class AppTemplateConfig(AppConfig):
    name = 'app_template'
